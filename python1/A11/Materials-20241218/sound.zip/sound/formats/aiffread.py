import os
import struct
import sys

def aiffread(filename):
    """Read AIFF file and return header information."""
    if not os.path.exists(filename):
        raise ValueError("File not found: {}".format(filename))
    with open(filename, mode='rb') as f:
        header = f.read(12)
    if len(header) != 12:
        raise ValueError("AIFF file too short: {}".format(filename))
    aiff = struct.unpack(">4sI4s", header)
    if aiff[0] != b'FORM':
        raise ValueError("Not an AIFF file: {}".format(filename))
    if aiff[2] != b'AIFF':
        raise ValueError("Not an AIFF file: {}".format(filename))
    return aiff
